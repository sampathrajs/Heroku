export const environment = {
  production: true,
   _userApiurl: 'http://192.168.0.133:50000/api/default/'
};
