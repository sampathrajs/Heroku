export class job {
    designation:string;
    companyname:string;
    place:string;
    jobtype:string;
    salary:number;
}
